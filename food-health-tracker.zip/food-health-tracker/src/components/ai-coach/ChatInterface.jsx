// src/components/ai-coach/ChatInterface.jsx
"use client";

import {
  useState,
  useRef,
  useEffect,
  useCallback,
} from "react";
import { getIdToken }  from "firebase/auth";
import { auth }        from "@/lib/firebase/firebaseConfig";
import { useAuth }     from "@/context/AuthContext";
import { useMacros }   from "@/lib/hooks/useMacros";

// ── Suggested prompts shown when chat is empty ─────────────────────────────
const SUGGESTED_PROMPTS = [
  { emoji: "🥗", text: "Give me a high-protein meal plan for today"           },
  { emoji: "🔄", text: "What can I substitute for white rice?"                },
  { emoji: "⏱️", text: "Explain the 16:8 fasting protocol"                   },
  { emoji: "💪", text: "What should I eat before and after a workout?"        },
  { emoji: "🛒", text: "Give me a healthy grocery list under ₹500"            },
  { emoji: "📊", text: "How do I hit my protein goal for the day?"            },
];

// ── Single chat message bubble ─────────────────────────────────────────────
function MessageBubble({ message }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : "flex-row"}`}>
      {/* Avatar */}
      <div
        className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm
          ${isUser ? "bg-emerald-500/20 text-emerald-400" : "bg-violet-500/20 text-violet-400"}`}
      >
        {isUser ? "👤" : "🤖"}
      </div>

      {/* Bubble */}
      <div
        className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed
          ${isUser
            ? "bg-emerald-500/10 border border-emerald-500/20 text-white rounded-tr-sm"
            : "bg-gray-900 border border-gray-800 text-gray-100 rounded-tl-sm"
          }`}
      >
        {/* Preserve line breaks and basic formatting from Gemini */}
        {message.text.split("\n").map((line, i) => {
          // Bold: **text**
          const formatted = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
          return (
            <p
              key={i}
              className={line === "" ? "mt-2" : ""}
              dangerouslySetInnerHTML={{ __html: formatted }}
            />
          );
        })}

        {/* Streaming cursor */}
        {message.streaming && (
          <span className="inline-block w-1.5 h-4 bg-violet-400 rounded-sm ml-1 animate-pulse align-text-bottom" />
        )}
      </div>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export default function ChatInterface() {
  const { user, userProfile }    = useAuth();
  const { macros }               = useMacros();

  const [messages,  setMessages]  = useState([]);     // { role, text, streaming? }
  const [input,     setInput]     = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const bottomRef    = useRef(null);
  const inputRef     = useRef(null);
  const abortRef     = useRef(null);                  // for cancelling in-flight requests

  // Auto-scroll to latest message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Build the Vertex AI history array from current messages
  const buildHistory = useCallback(() => {
    return messages
      .filter((m) => !m.streaming)                    // exclude partial messages
      .map((m) => ({
        role:  m.role === "user" ? "user" : "model",
        parts: [{ text: m.text }],
      }));
  }, [messages]);

  // Build the user's nutrition context for prompt enrichment
  const buildUserContext = useCallback(() => {
    if (!macros || !userProfile?.goals) return {};
    const g = userProfile.goals;
    const m = macros;
    return {
      dailyCalories:    g.dailyCalories,
      caloriesConsumed: m.calories.consumed,
      proteinGoal:      g.proteinGrams,
      proteinConsumed:  m.protein.consumed,
      carbsGoal:        g.carbsGrams,
      carbsConsumed:    m.carbs.consumed,
      fatGoal:          g.fatGrams,
      fatConsumed:      m.fat.consumed,
      goal:             userProfile?.metrics?.goal,
      activityLevel:    userProfile?.metrics?.activityLevel,
    };
  }, [macros, userProfile]);

  const sendMessage = useCallback(async (text) => {
    const trimmed = text.trim();
    if (!trimmed || isLoading || !user) return;

    // Cancel any previous in-flight request
    abortRef.current?.abort();
    const controller  = new AbortController();
    abortRef.current  = controller;

    const userMessage = { role: "user", text: trimmed };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    // Add a streaming placeholder for the assistant reply
    const assistantId = Date.now();
    setMessages((prev) => [
      ...prev,
      { id: assistantId, role: "model", text: "", streaming: true },
    ]);

    try {
      const idToken = await getIdToken(user);

      const res = await fetch("/api/ai-coach", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        signal:  controller.signal,
        body:    JSON.stringify({
          idToken,
          message:     trimmed,
          history:     buildHistory(),
          userContext: buildUserContext(),
        }),
      });

      if (!res.ok) throw new Error(`API error ${res.status}`);

      // ── Read the stream chunk by chunk ──────────────────────────────────
      const reader  = res.body.getReader();
      const decoder = new TextDecoder();
      let   accumulated = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        accumulated += decoder.decode(value, { stream: true });

        // Update the streaming bubble with every new chunk
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId
              ? { ...m, text: accumulated }
              : m
          )
        );
      }

      // Mark streaming as complete
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantId ? { ...m, streaming: false } : m
        )
      );
    } catch (err) {
      if (err.name === "AbortError") return;

      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantId
            ? {
                ...m,
                text:      "Sorry, FuelCoach is unavailable right now. Please try again.",
                streaming: false,
              }
            : m
        )
      );
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  }, [isLoading, user, buildHistory, buildUserContext]);

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage(input);
  };

  const handleSuggest = (text) => sendMessage(text);

  const clearChat = () => {
    abortRef.current?.abort();
    setMessages([]);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)]">

      {/* ── Header ────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-2xl bg-violet-500/20 border border-violet-500/30 flex items-center justify-center">
            🤖
          </div>
          <div>
            <p className="font-semibold text-white text-sm">FuelCoach</p>
            <p className="text-[10px] text-emerald-400">● Online · Powered by Gemini</p>
          </div>
        </div>

        {messages.length > 0 && (
          <button
            onClick={clearChat}
            className="text-xs text-gray-500 hover:text-white transition-colors px-3 py-1.5 rounded-xl hover:bg-gray-800"
          >
            Clear chat
          </button>
        )}
      </div>

      {/* ── Message list ──────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-4">

        {/* Empty state — suggested prompts */}
        {messages.length === 0 && (
          <div className="space-y-6">
            <div className="text-center space-y-2 pt-4">
              <p className="text-2xl">🥗</p>
              <p className="text-white font-semibold">Hi, I'm FuelCoach!</p>
              <p className="text-sm text-gray-400">
                Ask me anything about nutrition, meal planning, or your daily goals.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-2">
              {SUGGESTED_PROMPTS.map(({ emoji, text }) => (
                <button
                  key={text}
                  onClick={() => handleSuggest(text)}
                  className="flex items-center gap-3 rounded-2xl border border-gray-800 bg-gray-900
                             px-4 py-3 text-left text-sm text-gray-300 hover:border-violet-500/50
                             hover:bg-violet-500/5 hover:text-white transition-all"
                >
                  <span className="text-lg shrink-0">{emoji}</span>
                  <span>{text}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Rendered messages */}
        {messages.map((msg, index) => (
          <MessageBubble key={msg.id ?? index} message={msg} />
        ))}

        {/* Scroll anchor */}
        <div ref={bottomRef} />
      </div>

      {/* ── Input bar ─────────────────────────────────────────────────── */}
      <div className="px-4 py-4 border-t border-gray-800 bg-gray-950">
        <form onSubmit={handleSubmit} className="flex items-end gap-2">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              // Auto-resize up to 5 lines
              e.target.style.height = "auto";
              e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
            }}
            onKeyDown={(e) => {
              // Submit on Enter; Shift+Enter inserts newline
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
            placeholder="Ask FuelCoach anything…"
            rows={1}
            disabled={isLoading}
            className="flex-1 resize-none rounded-2xl border border-gray-800 bg-gray-900
                       px-4 py-3 text-sm text-white placeholder-gray-600 outline-none
                       focus:border-violet-500/50 disabled:opacity-60
                       transition-colors min-h-[48px] max-h-[120px]"
          />

          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="shrink-0 w-12 h-12 rounded-2xl bg-violet-500 flex items-center justify-center
                       hover:bg-violet-400 disabled:opacity-40 disabled:cursor-not-allowed
                       transition-all"
            aria-label="Send message"
          >
            {isLoading ? (
              <div className="w-4 h-4 rounded-full border-2 border-white/40 border-t-white animate-spin" />
            ) : (
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            )}
          </button>
        </form>

        <p className="text-center text-[10px] text-gray-600 mt-2">
          FuelCoach can make mistakes. Not a substitute for medical advice.
        </p>
      </div>

    </div>
  );
}