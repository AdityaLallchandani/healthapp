// src/components/logging/FoodSearch.jsx
"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { getIdToken } from "firebase/auth";
import { auth } from "@/lib/firebase/firebaseConfig";
import { format } from "date-fns";
import toast from "react-hot-toast";

const MEAL_TYPES = ["breakfast", "lunch", "dinner", "snack"];

// Preset serving sizes in grams (1× = food.servingSize or 100g default)
const SERVING_OPTIONS = [
  { label: "0.5× (50g)", value: 0.5 },
  { label: "1× (100g)", value: 1   },
  { label: "1.5× (150g)", value: 1.5 },
  { label: "2× (200g)", value: 2   },
];

export default function FoodSearch({ date = new Date() }) {
  const [query,     setQuery]     = useState("");
  const [results,   setResults]   = useState([]);
  const [searching, setSearching] = useState(false);
  const [selected,  setSelected]  = useState(null);      // food item chosen
  const [serving,   setServing]   = useState(1);
  const [mealType,  setMealType]  = useState("snack");
  const [logging,   setLogging]   = useState(false);

  const debounceRef = useRef(null);
  const dateKey     = format(date, "yyyy-MM-dd");

  // Debounced search — fires 400ms after the user stops typing
  useEffect(() => {
    clearTimeout(debounceRef.current);

    if (query.trim().length < 2) {
      setResults([]);
      return;
    }

    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const res  = await fetch(`/api/food-search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        setResults(data.products ?? []);
      } catch {
        toast.error("Search failed");
      } finally {
        setSearching(false);
      }
    }, 400);

    return () => clearTimeout(debounceRef.current);
  }, [query]);

  const handleLog = useCallback(async () => {
    if (!selected) return;
    setLogging(true);

    try {
      const idToken = await getIdToken(auth.currentUser);

      const res = await fetch("/api/log-food", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({
          idToken,
          food:              selected,
          servingMultiplier: serving,
          mealType,
          date:              dateKey,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      toast.success(`Logged ${selected.name} (${data.macros.calories} kcal)`);

      // Reset state after successful log
      setSelected(null);
      setQuery("");
      setResults([]);
      setServing(1);
    } catch (err) {
      toast.error(err.message ?? "Failed to log food");
    } finally {
      setLogging(false);
    }
  }, [selected, serving, mealType, dateKey]);

  return (
    <div className="space-y-4">
      {/* ── Search input ── */}
      <div className="relative">
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search food (e.g. banana, oats, chicken)"
          className="input pr-10"
        />
        {searching && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin" />
        )}
      </div>

      {/* ── Results list ── */}
      {results.length > 0 && !selected && (
        <ul className="rounded-2xl border border-gray-800 bg-gray-900 divide-y divide-gray-800 overflow-hidden max-h-72 overflow-y-auto">
          {results.map((food) => (
            <li key={food.id}>
              <button
                onClick={() => {
                  setSelected(food);
                  setQuery(food.name);
                  setResults([]);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-800 transition-colors text-left"
              >
                {food.imageUrl ? (
                  <img
                    src={food.imageUrl}
                    alt={food.name}
                    className="w-10 h-10 rounded-xl object-cover shrink-0 bg-gray-800"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-gray-800 flex items-center justify-center text-lg shrink-0">
                    🍽️
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{food.name}</p>
                  <p className="text-xs text-gray-500">{food.brand || "Generic"}</p>
                </div>

                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-emerald-400">
                    {food.nutrition.calories}
                  </p>
                  <p className="text-[10px] text-gray-500">kcal/100g</p>
                </div>
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* ── Selected food — serving + meal type ── */}
      {selected && (
        <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-4 space-y-4">
          {/* Selected food header */}
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold text-white">{selected.name}</p>
              <p className="text-xs text-gray-400">{selected.brand}</p>
            </div>
            <button
              onClick={() => { setSelected(null); setQuery(""); }}
              className="text-gray-500 hover:text-white text-xl leading-none"
            >
              ×
            </button>
          </div>

          {/* Nutrition preview for selected serving */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { label: "Calories", value: Math.round(selected.nutrition.calories * serving), unit: "kcal", color: "text-emerald-400" },
              { label: "Protein",  value: Math.round(selected.nutrition.protein  * serving), unit: "g",    color: "text-indigo-400"  },
              { label: "Carbs",    value: Math.round(selected.nutrition.carbs    * serving), unit: "g",    color: "text-amber-400"   },
              { label: "Fat",      value: Math.round(selected.nutrition.fat      * serving), unit: "g",    color: "text-red-400"     },
            ].map(({ label, value, unit, color }) => (
              <div key={label} className="rounded-xl bg-gray-900 p-2 text-center">
                <p className={`text-sm font-bold ${color}`}>{value}</p>
                <p className="text-[10px] text-gray-500">{unit}</p>
                <p className="text-[10px] text-gray-600">{label}</p>
              </div>
            ))}
          </div>

          {/* Serving size selector */}
          <div>
            <label className="text-xs text-gray-400 block mb-1">Serving size</label>
            <div className="grid grid-cols-4 gap-2">
              {SERVING_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setServing(opt.value)}
                  className={`rounded-xl border py-2 text-xs font-medium transition-all ${
                    serving === opt.value
                      ? "border-emerald-500 bg-emerald-500/10 text-emerald-400"
                      : "border-gray-800 text-gray-400 hover:border-gray-600"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Meal type selector */}
          <div>
            <label className="text-xs text-gray-400 block mb-1">Meal</label>
            <div className="grid grid-cols-4 gap-2">
              {MEAL_TYPES.map((type) => (
                <button
                  key={type}
                  onClick={() => setMealType(type)}
                  className={`rounded-xl border py-2 text-xs font-medium capitalize transition-all ${
                    mealType === type
                      ? "border-emerald-500 bg-emerald-500/10 text-emerald-400"
                      : "border-gray-800 text-gray-400 hover:border-gray-600"
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Confirm log button */}
          <button
            onClick={handleLog}
            disabled={logging}
            className="w-full rounded-2xl bg-emerald-500 py-3 font-semibold text-black hover:bg-emerald-400 disabled:opacity-60 transition-colors"
          >
            {logging ? "Logging…" : "Add to Log"}
          </button>
        </div>
      )}
    </div>
  );
}