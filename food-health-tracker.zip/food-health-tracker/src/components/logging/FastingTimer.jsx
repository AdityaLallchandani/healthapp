// src/components/logging/FastingTimer.jsx
"use client";

import { useState, useEffect, useCallback } from "react";
import { format } from "date-fns";
import { updateFastingTimer } from "@/lib/firebase/firestore";
import { useAuth } from "@/context/AuthContext";
import { useDailyLog } from "@/lib/hooks/useDailyLog";
import toast from "react-hot-toast";

// Popular fasting protocols
const PROTOCOLS = [
  { label: "16:8",  hours: 16, description: "Fast 16h, eat in 8h window"  },
  { label: "18:6",  hours: 18, description: "Fast 18h, eat in 6h window"  },
  { label: "20:4",  hours: 20, description: "Fast 20h, eat in 4h window"  },
  { label: "24h",   hours: 24, description: "Full 24-hour fast"           },
];

function formatDuration(seconds) {
  if (seconds < 0) seconds = 0;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function FastingTimer({ date = new Date() }) {
  const { user }  = useAuth();
  const dateKey   = format(date, "yyyy-MM-dd");
  const { log }   = useDailyLog(date);

  const [elapsed,  setElapsed]  = useState(0);
  const [protocol, setProtocol] = useState(PROTOCOLS[0]);

  // Derive fasting state from live Firestore log
  const fastingStart = log?.fastingStart?.toDate?.() ?? null;
  const isFasting    = !!fastingStart;

  // goal in seconds for the chosen protocol
  const goalSeconds = protocol.hours * 3600;

  // Tick every second while fasting is active
  useEffect(() => {
    if (!isFasting) { setElapsed(0); return; }

    const tick = () => {
      const diff = Math.floor((Date.now() - fastingStart.getTime()) / 1000);
      setElapsed(diff);
    };

    tick(); // immediate first tick
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [isFasting, fastingStart]);

  const progress = Math.min(elapsed / goalSeconds, 1);
  const remaining = Math.max(goalSeconds - elapsed, 0);
  const isComplete = elapsed >= goalSeconds;

  const startFast = useCallback(async () => {
    if (!user) return;
    try {
      await updateFastingTimer(user.uid, dateKey, new Date());
      toast.success("Fast started ⏱️");
    } catch {
      toast.error("Could not start fast");
    }
  }, [user, dateKey]);

  const stopFast = useCallback(async () => {
    if (!user) return;
    try {
      await updateFastingTimer(user.uid, dateKey, null);
      toast.success(`Fast ended — ${formatDuration(elapsed)} completed 🎉`);
    } catch {
      toast.error("Could not stop fast");
    }
  }, [user, dateKey, elapsed]);

  // SVG ring dimensions
  const size        = 200;
  const strokeWidth = 12;
  const radius      = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset      = circumference * (1 - progress);

  return (
    <div className="space-y-6">
      {/* Protocol picker — only shown when not fasting */}
      {!isFasting && (
        <div>
          <p className="text-xs text-gray-400 mb-2">Choose a protocol</p>
          <div className="grid grid-cols-4 gap-2">
            {PROTOCOLS.map((p) => (
              <button
                key={p.label}
                onClick={() => setProtocol(p)}
                className={`rounded-2xl border py-2.5 text-xs font-semibold transition-all ${
                  protocol.label === p.label
                    ? "border-amber-500 bg-amber-500/10 text-amber-400"
                    : "border-gray-800 text-gray-400 hover:border-gray-600"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-2 text-center">{protocol.description}</p>
        </div>
      )}

      {/* Timer ring */}
      <div className="flex flex-col items-center gap-4">
        <div className="relative" style={{ width: size, height: size }}>
          <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
            {/* Track */}
            <circle
              cx={size / 2} cy={size / 2} r={radius}
              fill="none" stroke="#1f2937" strokeWidth={strokeWidth}
            />
            {/* Progress — green when complete */}
            <circle
              cx={size / 2} cy={size / 2} r={radius}
              fill="none"
              stroke={isComplete ? "#10b981" : "#f59e0b"}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              style={{ transition: "stroke-dashoffset 1s linear, stroke 0.3s" }}
            />
          </svg>

          {/* Center content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-1">
            {isFasting ? (
              <>
                <span className="text-3xl font-bold font-mono text-white">
                  {formatDuration(elapsed)}
                </span>
                <span className="text-xs text-gray-400">elapsed</span>
                {!isComplete && (
                  <span className="text-[11px] text-amber-400 mt-1">
                    {formatDuration(remaining)} to go
                  </span>
                )}
                {isComplete && (
                  <span className="text-[11px] text-emerald-400 font-semibold mt-1">
                    Goal reached! 🎉
                  </span>
                )}
              </>
            ) : (
              <>
                <span className="text-4xl">⏱️</span>
                <span className="text-sm text-gray-400 mt-1">{protocol.label} fast</span>
              </>
            )}
          </div>
        </div>

        {/* Start / Stop button */}
        <button
          onClick={isFasting ? stopFast : startFast}
          className={`w-40 rounded-2xl py-3 font-semibold transition-all ${
            isFasting
              ? "bg-red-500/10 border border-red-500/40 text-red-400 hover:bg-red-500/20"
              : "bg-amber-500 text-black hover:bg-amber-400"
          }`}
        >
          {isFasting ? "End Fast" : "Start Fast"}
        </button>

        {/* Start time label */}
        {isFasting && fastingStart && (
          <p className="text-xs text-gray-500">
            Started at {format(fastingStart, "hh:mm a")}
          </p>
        )}
      </div>
    </div>
  );
}