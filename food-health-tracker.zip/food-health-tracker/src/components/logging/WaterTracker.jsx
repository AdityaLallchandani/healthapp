// src/components/logging/WaterTracker.jsx
"use client";

import { useState } from "react";
import { format } from "date-fns";
import { logWater } from "@/lib/firebase/firestore";
import { useAuth } from "@/context/AuthContext";
import { useDailyLog } from "@/lib/hooks/useDailyLog";
import toast from "react-hot-toast";

const PRESETS = [
  { label: "Small\n150ml", ml: 150, emoji: "🥤" },
  { label: "Glass\n250ml", ml: 250, emoji: "🥛" },
  { label: "Bottle\n500ml", ml: 500, emoji: "🍶" },
  { label: "Large\n750ml", ml: 750, emoji: "💧" },
];

const DAILY_GOAL_ML = 2500;

export default function WaterTracker({ date = new Date() }) {
  const { user } = useAuth();
  const dateKey  = format(date, "yyyy-MM-dd");
  const { log }  = useDailyLog(date);     // real-time from Module B hook
  const [lastAdded, setLastAdded] = useState(null);

  const currentMl = log?.waterMl ?? 0;
  const progress  = Math.min(currentMl / DAILY_GOAL_ML, 1);
  const remaining = Math.max(DAILY_GOAL_ML - currentMl, 0);

  const handleAdd = async (ml) => {
    if (!user) return;
    try {
      await logWater(user.uid, dateKey, ml);
      setLastAdded(ml);
      toast.success(`+${ml}ml added 💧`);
    } catch {
      toast.error("Failed to log water");
    }
  };

  const handleUndo = async () => {
    if (!lastAdded || !user) return;
    try {
      await logWater(user.uid, dateKey, -lastAdded); // negative increment = undo
      toast.success(`Removed ${lastAdded}ml`);
      setLastAdded(null);
    } catch {
      toast.error("Undo failed");
    }
  };

  return (
    <div className="space-y-5">
      {/* Progress bar + label */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">
            <span className="text-sky-400 font-semibold">{currentMl}ml</span> drank
          </span>
          <span className="text-gray-500">{remaining}ml remaining</span>
        </div>

        <div className="h-3 rounded-full bg-gray-800 overflow-hidden">
          <div
            className="h-full rounded-full bg-sky-400 transition-all duration-500"
            style={{ width: `${progress * 100}%` }}
          />
        </div>

        <p className="text-center text-xs text-gray-500">
          Goal: {DAILY_GOAL_ML / 1000}L per day
        </p>
      </div>

      {/* Preset buttons */}
      <div className="grid grid-cols-4 gap-3">
        {PRESETS.map(({ label, ml, emoji }) => (
          <button
            key={ml}
            onClick={() => handleAdd(ml)}
            className="flex flex-col items-center gap-1.5 rounded-2xl border border-gray-800 bg-gray-900 py-4 hover:border-sky-500/50 hover:bg-sky-500/5 transition-all"
          >
            <span className="text-2xl">{emoji}</span>
            <span className="text-[10px] text-gray-400 whitespace-pre-line text-center leading-tight">
              {label}
            </span>
          </button>
        ))}
      </div>

      {/* Custom amount input */}
      <CustomWaterInput onAdd={handleAdd} />

      {/* Undo last entry */}
      {lastAdded && (
        <button
          onClick={handleUndo}
          className="w-full rounded-2xl border border-gray-800 py-2.5 text-sm text-gray-400 hover:text-white hover:border-gray-600 transition-colors"
        >
          Undo last entry ({lastAdded}ml)
        </button>
      )}
    </div>
  );
}

function CustomWaterInput({ onAdd }) {
  const [value, setValue] = useState("");

  const submit = () => {
    const ml = parseInt(value, 10);
    if (isNaN(ml) || ml <= 0 || ml > 5000) {
      toast.error("Enter a value between 1 and 5000ml");
      return;
    }
    onAdd(ml);
    setValue("");
  };

  return (
    <div className="flex gap-2">
      <input
        type="number"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && submit()}
        placeholder="Custom amount (ml)"
        min="1"
        max="5000"
        className="input flex-1"
      />
      <button
        onClick={submit}
        className="shrink-0 rounded-2xl bg-sky-500 px-4 font-medium text-white hover:bg-sky-400 transition-colors"
      >
        Add
      </button>
    </div>
  );
}