// src/components/dashboard/CalorieRing.jsx
// ─────────────────────────────────────────────────────────────────────────────
// Large hero calorie ring shown at the top of the dashboard.
// Turns red with an "over budget" badge if consumed > goal.
// ─────────────────────────────────────────────────────────────────────────────
"use client";

import { useEffect, useRef } from "react";

export default function CalorieRing({
  consumed = 0,
  goal     = 2000,
  progress = 0,
}) {
  const circleRef   = useRef(null);
  const size        = 220;
  const strokeWidth = 14;
  const radius      = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const center      = size / 2;

  const overBudget = consumed > goal;
  const remaining  = Math.max(goal - consumed, 0);

  useEffect(() => {
    if (!circleRef.current) return;
    circleRef.current.style.strokeDashoffset = circumference * (1 - Math.min(progress, 1));
  }, [progress, circumference]);

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          style={{ transform: "rotate(-90deg)" }}
          aria-label={`Calories: ${consumed} of ${goal} kcal`}
          role="img"
        >
          {/* Track ring */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke="#1f2937"
            strokeWidth={strokeWidth}
          />

          {/* Progress ring — green normally, red when over budget */}
          <circle
            ref={circleRef}
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke={overBudget ? "#ef4444" : "#10b981"}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference}
            style={{
              transition: "stroke-dashoffset 0.8s ease-in-out, stroke 0.3s ease",
            }}
          />
        </svg>

        {/* Center label stack */}
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-0.5">
          <span className="text-4xl font-bold text-white tabular-nums">
            {consumed}
          </span>
          <span className="text-sm text-gray-400">of {goal} kcal</span>

          {/* Status badge */}
          <span
            className={`mt-2 text-xs font-semibold px-3 py-1 rounded-full ${
              overBudget
                ? "bg-red-500/20 text-red-400"
                : "bg-emerald-500/20 text-emerald-400"
            }`}
          >
            {overBudget
              ? `${consumed - goal} over budget`
              : `${remaining} kcal left`}
          </span>
        </div>
      </div>
    </div>
  );
}