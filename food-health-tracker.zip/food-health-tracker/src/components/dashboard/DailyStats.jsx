// src/components/dashboard/DailyStats.jsx
// ─────────────────────────────────────────────────────────────────────────────
// Three quick-glance stat cards: Eaten / Remaining / Water.
// Renders null safely when macros haven't loaded yet.
// ─────────────────────────────────────────────────────────────────────────────
"use client";

export default function DailyStats({ macros }) {
  if (!macros) return null;

  const stats = [
    {
      label: "Eaten",
      value: macros.calories.consumed,
      unit:  "kcal",
      icon:  "🍽️",
      color: "text-emerald-400",
    },
    {
      label: "Remaining",
      value: macros.calories.remaining,
      unit:  "kcal",
      icon:  "🎯",
      color: "text-amber-400",
    },
    {
      label: "Water",
      // Convert ml → L with one decimal place for readability
      value: (macros.water.consumed / 1000).toFixed(1),
      unit:  "L",
      icon:  "💧",
      color: "text-sky-400",
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-3">
      {stats.map(({ label, value, unit, icon, color }) => (
        <div
          key={label}
          className="flex flex-col items-center gap-1 rounded-2xl border border-gray-800 bg-gray-900 py-4 px-2"
        >
          <span className="text-xl"        >{icon}</span>
          <span className={`text-lg font-bold tabular-nums ${color}`}>{value}</span>
          <span className="text-[10px] text-gray-500">{unit}</span>
          <span className="text-xs text-gray-400">{label}</span>
        </div>
      ))}
    </div>
  );
}