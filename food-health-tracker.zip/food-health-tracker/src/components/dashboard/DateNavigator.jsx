// src/components/dashboard/DateNavigator.jsx
// ─────────────────────────────────────────────────────────────────────────────
// Prev / Next day navigator. Forward arrow is disabled on today
// so users can't navigate into the future.
// The selected date is lifted up to dashboard/page.jsx so both
// CalorieRing and MacroRings subscribe to the same date.
// ─────────────────────────────────────────────────────────────────────────────
"use client";

import { format, addDays, isToday } from "date-fns";

/**
 * @param {Date}                  date         - Currently selected date
 * @param {(date: Date) => void}  onDateChange - Callback to update parent state
 */
export default function DateNavigator({ date, onDateChange }) {
  const isTodaySelected = isToday(date);

  return (
    <div className="flex items-center justify-between rounded-2xl border border-gray-800 bg-gray-900 px-4 py-3">
      {/* Previous day */}
      <button
        onClick={() => onDateChange(addDays(date, -1))}
        className="w-9 h-9 flex items-center justify-center rounded-xl text-gray-400
                   hover:bg-gray-800 hover:text-white transition-colors text-xl leading-none"
        aria-label="Previous day"
      >
        ‹
      </button>

      {/* Date label */}
      <div className="text-center">
        <p className="text-sm font-semibold text-white">
          {isTodaySelected ? "Today" : format(date, "EEEE")}
        </p>
        <p className="text-xs text-gray-500">{format(date, "dd MMM yyyy")}</p>
      </div>

      {/* Next day — disabled on today */}
      <button
        onClick={() => onDateChange(addDays(date, 1))}
        disabled={isTodaySelected}
        className="w-9 h-9 flex items-center justify-center rounded-xl text-gray-400
                   hover:bg-gray-800 hover:text-white transition-colors text-xl leading-none
                   disabled:opacity-30 disabled:cursor-not-allowed"
        aria-label="Next day"
      >
        ›
      </button>
    </div>
  );
}