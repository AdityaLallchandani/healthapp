// src/components/dashboard/MacroRing.jsx
// ─────────────────────────────────────────────────────────────────────────────
// Animated SVG circular progress ring for individual macros.
// Uses stroke-dashoffset technique — no third-party chart dependency needed.
// Props:
//   size        {number}  - Outer pixel dimension (default 120)
//   strokeWidth {number}  - Ring thickness in px (default 10)
//   progress    {number}  - 0 to 1 (clamped externally by useMacros hook)
//   color       {string}  - Ring stroke color (hex or CSS value)
//   label       {string}  - Macro name displayed below the ring
//   consumed    {number}  - Amount consumed today
//   goal        {number}  - Daily target
//   unit        {string}  - "g", "kcal", or "ml"
// ─────────────────────────────────────────────────────────────────────────────
"use client";

import { useEffect, useRef } from "react";

export default function MacroRing({
  size        = 120,
  strokeWidth = 10,
  progress    = 0,
  color       = "#10b981",
  label       = "",
  consumed    = 0,
  goal        = 0,
  unit        = "g",
}) {
  const circleRef   = useRef(null);
  const radius      = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const center      = size / 2;
  const percentage  = Math.round(progress * 100);

  // Animate the dashoffset whenever progress changes.
  // Starting at full circumference (empty) and transitioning to the target
  // creates the fill-in effect on mount and on every update.
  useEffect(() => {
    if (!circleRef.current) return;
    circleRef.current.style.strokeDashoffset = circumference * (1 - progress);
  }, [progress, circumference]);

  return (
    <div className="flex flex-col items-center gap-2">

      {/* SVG ring */}
      <div className="relative" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          // Rotate so the ring starts filling from the top (12 o'clock)
          style={{ transform: "rotate(-90deg)" }}
          aria-label={`${label}: ${consumed}${unit} of ${goal}${unit}`}
          role="img"
        >
          {/* Background / track ring */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke="#1f2937"
            strokeWidth={strokeWidth}
          />

          {/* Animated progress ring */}
          <circle
            ref={circleRef}
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            // Starts at full offset (empty ring); useEffect transitions it to target
            strokeDashoffset={circumference}
            style={{
              transition: "stroke-dashoffset 0.8s ease-in-out",
            }}
          />
        </svg>

        {/* Center value text — positioned over the SVG */}
        <div
          className="absolute inset-0 flex flex-col items-center justify-center"
        >
          <span className="text-base font-bold text-white leading-none">
            {consumed}
          </span>
          <span className="text-[10px] text-gray-500 mt-0.5">{unit}</span>
        </div>
      </div>

      {/* Label row below the ring */}
      <div className="text-center">
        <p className="text-xs font-medium text-gray-300">{label}</p>
        <p className="text-[10px] text-gray-500">
          {percentage}% of {goal}{unit}
        </p>
      </div>

    </div>
  );
}