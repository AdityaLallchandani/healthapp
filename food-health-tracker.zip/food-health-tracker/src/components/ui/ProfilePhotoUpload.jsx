// src/components/ui/ProfilePhotoUpload.jsx
"use client";

import { useState, useRef }                   from "react";
import { uploadProfilePicture }               from "@/lib/gcp/storage";
import { useAuth }                            from "@/context/AuthContext";
import toast                                  from "react-hot-toast";

export default function ProfilePhotoUpload() {
  const { user, userProfile, setUserProfile } = useAuth();
  const [progress, setProgress]               = useState(0);
  const [uploading, setUploading]             = useState(false);
  const [preview,   setPreview]               = useState(null);
  const inputRef                              = useRef(null);

  const handleFile = async (file) => {
    if (!file || !user) return;

    // Show instant local preview
    setPreview(URL.createObjectURL(file));
    setUploading(true);
    setProgress(0);

    try {
      const downloadURL = await uploadProfilePicture(user.uid, file, setProgress);

      // Update local auth context so the avatar updates everywhere immediately
      setUserProfile((prev) => ({ ...prev, photoURL: downloadURL }));
      toast.success("Profile photo updated!");
    } catch (err) {
      toast.error(err.message ?? "Upload failed");
      setPreview(null);           // revert preview on error
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  const handleInputChange = (e) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const currentPhoto = preview ?? userProfile?.photoURL;

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Avatar with upload overlay */}
      <div
        className="relative w-24 h-24 rounded-full cursor-pointer group"
        onClick={() => inputRef.current?.click()}
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
      >
        {/* Photo or placeholder */}
        {currentPhoto ? (
          <img
            src={currentPhoto}
            alt="Profile"
            className="w-full h-full rounded-full object-cover border-2 border-gray-700"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full rounded-full bg-gray-800 border-2 border-gray-700 flex items-center justify-center text-3xl">
            👤
          </div>
        )}

        {/* Hover overlay */}
        {!uploading && (
          <div className="absolute inset-0 rounded-full bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <span className="text-white text-xs font-medium">Change</span>
          </div>
        )}

        {/* Upload progress ring overlay */}
        {uploading && (
          <div className="absolute inset-0 rounded-full bg-black/70 flex items-center justify-center">
            <svg className="w-full h-full absolute inset-0" style={{ transform: "rotate(-90deg)" }}>
              <circle cx="48" cy="48" r="44" fill="none" stroke="#1f2937" strokeWidth="4" />
              <circle
                cx="48" cy="48" r="44"
                fill="none"
                stroke="#10b981"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 44}
                strokeDashoffset={2 * Math.PI * 44 * (1 - progress / 100)}
                style={{ transition: "stroke-dashoffset 0.2s ease" }}
              />
            </svg>
            <span className="text-white text-xs font-bold z-10">{progress}%</span>
          </div>
        )}
      </div>

      {/* Hidden file input */}
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleInputChange}
      />

      <p className="text-xs text-gray-500">
        Click or drag an image · Max 5 MB
      </p>
    </div>
  );
}