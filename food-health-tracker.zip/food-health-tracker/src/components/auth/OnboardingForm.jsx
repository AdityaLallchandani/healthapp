"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { doc, updateDoc, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase/firebaseConfig";
import { useAuth } from "@/context/AuthContext";
import {
  ACTIVITY_LEVELS,
  GOALS,
  calculateMacros
} from "@/lib/utils/tdee";

const steps = ["Metrics", "Activity", "Goal", "Review"];

export default function OnboardingForm() {
  const router = useRouter();
  const { user, userProfile, setUserProfile } = useAuth();

  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    heightCm: userProfile?.metrics?.heightCm || "",
    weightKg: userProfile?.metrics?.weightKg || "",
    age: userProfile?.metrics?.age || "",
    gender: userProfile?.metrics?.gender || "male",
    activityLevel: userProfile?.metrics?.activityLevel || "moderate",
    goal: userProfile?.metrics?.goal || "maintain"
  });

  const preview = useMemo(() => {
    if (!form.heightCm || !form.weightKg || !form.age) return null;
    return calculateMacros({
      heightCm: Number(form.heightCm),
      weightKg: Number(form.weightKg),
      age: Number(form.age),
      gender: form.gender,
      activityLevel: form.activityLevel,
      goal: form.goal
    });
  }, [form]);

  const updateField = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const next = () => setStep((s) => Math.min(s + 1, steps.length - 1));
  const back = () => setStep((s) => Math.max(s - 1, 0));

  const saveProfile = async () => {
    if (!user) return;

    setSaving(true);
    try {
      const macros = calculateMacros({
        heightCm: Number(form.heightCm),
        weightKg: Number(form.weightKg),
        age: Number(form.age),
        gender: form.gender,
        activityLevel: form.activityLevel,
        goal: form.goal
      });

      const payload = {
        onboardingComplete: true,
        metrics: {
          heightCm: Number(form.heightCm),
          weightKg: Number(form.weightKg),
          age: Number(form.age),
          gender: form.gender,
          activityLevel: form.activityLevel,
          goal: form.goal
        },
        goals: {
          dailyCalories: macros.dailyCalories,
          proteinGrams: macros.proteinGrams,
          carbsGrams: macros.carbsGrams,
          fatGrams: macros.fatGrams
        },
        updatedAt: serverTimestamp()
      };

      await updateDoc(doc(db, "users", user.uid), payload);
      setUserProfile((prev) => ({ ...prev, ...payload }));
      router.push("/dashboard");
    } catch (err) {
      console.error(err);
      alert("Failed to save onboarding data");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="mb-6 flex items-center justify-between text-sm text-gray-400">
        {steps.map((label, index) => (
          <span key={label} className={index === step ? "text-emerald-400" : ""}>
            {index + 1}. {label}
          </span>
        ))}
      </div>

      <div className="rounded-3xl border border-gray-800 bg-gray-900 p-6 md:p-8">
        {step === 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Your basics</h2>
            <input className="input" placeholder="Height (cm)" value={form.heightCm} onChange={(e) => updateField("heightCm", e.target.value)} />
            <input className="input" placeholder="Weight (kg)" value={form.weightKg} onChange={(e) => updateField("weightKg", e.target.value)} />
            <input className="input" placeholder="Age" value={form.age} onChange={(e) => updateField("age", e.target.value)} />
            <select className="input" value={form.gender} onChange={(e) => updateField("gender", e.target.value)}>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Activity level</h2>
            <div className="grid gap-3">
              {ACTIVITY_LEVELS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => updateField("activityLevel", item.id)}
                  className={`rounded-2xl border px-4 py-3 text-left ${form.activityLevel === item.id ? "border-emerald-500 bg-emerald-500/10" : "border-gray-800 bg-gray-950"}`}
                >
                  <div className="font-medium">{item.label}</div>
                  <div className="text-sm text-gray-400">{item.description}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Your goal</h2>
            <div className="grid gap-3 md:grid-cols-3">
              {GOALS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => updateField("goal", item.id)}
                  className={`rounded-2xl border px-4 py-5 text-center ${form.goal === item.id ? "border-emerald-500 bg-emerald-500/10" : "border-gray-800 bg-gray-950"}`}
                >
                  <div className="text-2xl mb-2">{item.emoji}</div>
                  <div className="font-medium">{item.label}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5">
            <h2 className="text-2xl font-semibold">Review your plan</h2>
            {preview && (
              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-2xl bg-gray-950 p-4 border border-gray-800">
                  <p className="text-sm text-gray-400">Daily Calories</p>
                  <p className="text-2xl font-bold">{preview.dailyCalories}</p>
                </div>
                <div className="rounded-2xl bg-gray-950 p-4 border border-gray-800">
                  <p className="text-sm text-gray-400">Protein</p>
                  <p className="text-2xl font-bold">{preview.proteinGrams}g</p>
                </div>
                <div className="rounded-2xl bg-gray-950 p-4 border border-gray-800">
                  <p className="text-sm text-gray-400">Carbs</p>
                  <p className="text-2xl font-bold">{preview.carbsGrams}g</p>
                </div>
                <div className="rounded-2xl bg-gray-950 p-4 border border-gray-800">
                  <p className="text-sm text-gray-400">Fat</p>
                  <p className="text-2xl font-bold">{preview.fatGrams}g</p>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="mt-8 flex items-center justify-between">
          <button
            onClick={back}
            disabled={step === 0}
            className="rounded-xl border border-gray-800 px-4 py-2 disabled:opacity-40"
          >
            Back
          </button>

          {step < steps.length - 1 ? (
            <button
              onClick={next}
              className="rounded-xl bg-emerald-500 px-5 py-2 font-medium text-black"
            >
              Next
            </button>
          ) : (
            <button
              onClick={saveProfile}
              disabled={saving}
              className="rounded-xl bg-emerald-500 px-5 py-2 font-medium text-black disabled:opacity-60"
            >
              {saving ? "Saving..." : "Finish Setup"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}