"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signInWithPopup } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db, googleProvider } from "@/lib/firebase/firebaseConfig";

export default function GoogleLoginButton() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  const handleLogin = async () => {
    setLoading(true);
    setError("");

    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;

      const snap = await getDoc(doc(db, "users", user.uid));
      const onboardingComplete = snap.exists() ? snap.data().onboardingComplete : false;

      router.push(onboardingComplete ? "/dashboard" : "/onboarding");
    } catch (err) {
      setError("Google sign-in failed. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      <button
        onClick={handleLogin}
        disabled={loading}
        className="w-full rounded-2xl bg-white text-gray-900 font-medium px-5 py-3 hover:bg-gray-100 disabled:opacity-60"
      >
        {loading ? "Signing in..." : "Continue with Google"}
      </button>
      {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
    </div>
  );
}