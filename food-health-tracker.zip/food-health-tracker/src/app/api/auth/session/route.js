// src/app/api/auth/session/route.js
// ─────────────────────────────────────────────────────────────────────────────
// Called client-side after signInWithPopup succeeds.
// Receives the Firebase ID token, verifies it server-side, then sets an
// HttpOnly session cookie so the middleware can protect routes.
// ─────────────────────────────────────────────────────────────────────────────
import { NextResponse }  from "next/server";
import { adminAuth }     from "@/lib/firebase/firebaseAdmin";
import { cookies }       from "next/headers";

const SESSION_MAX_AGE = 60 * 60 * 24 * 7; // 7 days in seconds

export async function POST(request) {
  try {
    const { idToken } = await request.json();
    if (!idToken) return NextResponse.json({ error: "Missing token" }, { status: 400 });

    // Verify the token is genuine (not forged)
    await adminAuth.verifyIdToken(idToken);

    // Set lightweight session cookie — NOT the token itself (too large for cookies)
    const cookieStore = await cookies();
    cookieStore.set("fueltrack_session", "authenticated", {
      httpOnly: true,
      secure:   process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge:   SESSION_MAX_AGE,
      path:     "/",
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[session/route]", err.message);
    return NextResponse.json({ error: "Invalid token" }, { status: 401 });
  }
}

export async function DELETE() {
  const cookieStore = await cookies();
  cookieStore.delete("fueltrack_session");
  return NextResponse.json({ success: true });
}