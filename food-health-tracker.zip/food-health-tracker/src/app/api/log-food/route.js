// src/app/api/log-food/route.js
// ─────────────────────────────────────────────────────────────────────────────
// Receives a food item + serving size, verifies the session, then:
//   1. Adds a document to /users/{uid}/daily_logs/{date}/meals
//   2. Increments the daily_log totals using FieldValue.increment()
//      so concurrent writes don't overwrite each other.
// ─────────────────────────────────────────────────────────────────────────────
import { NextResponse }  from "next/server";
import { cookies }       from "next/headers";
import { adminAuth, adminDb } from "@/lib/firebase/firebaseAdmin";
import { FieldValue }    from "firebase-admin/firestore";

export async function POST(request) {
  // ── Auth check ────────────────────────────────────────────────────────────
  const cookieStore = await cookies();
  const session = cookieStore.get("fueltrack_session")?.value;
  if (!session) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });

  try {
    const body = await request.json();
    const { idToken, food, servingMultiplier = 1, mealType = "snack", date } = body;

    // Verify the Firebase ID token sent from the client
    const decoded = await adminAuth.verifyIdToken(idToken);
    const uid     = decoded.uid;

    // Calculate actual macros based on serving size (food nutrition is per 100g)
    const macros = {
      calories: Math.round(food.nutrition.calories * servingMultiplier),
      protein:  Math.round(food.nutrition.protein  * servingMultiplier),
      carbs:    Math.round(food.nutrition.carbs     * servingMultiplier),
      fat:      Math.round(food.nutrition.fat       * servingMultiplier),
    };

    const dateKey   = date ?? new Date().toISOString().split("T")[0];
    const logRef    = adminDb.doc(`users/${uid}/daily_logs/${dateKey}`);
    const mealsRef  = logRef.collection("meals").doc(); // auto-ID

    // Atomic batch: meal doc + daily totals update
    const batch = adminDb.batch();

    batch.set(mealsRef, {
      foodId:   food.id,
      name:     food.name,
      brand:    food.brand,
      mealType,
      servingMultiplier,
      servingLabel: food.servingSize,
      ...macros,
      loggedAt: FieldValue.serverTimestamp(),
    });

    // increment() is atomic — safe even with concurrent writes
    batch.update(logRef, {
      totalCalories: FieldValue.increment(macros.calories),
      totalProtein:  FieldValue.increment(macros.protein),
      totalCarbs:    FieldValue.increment(macros.carbs),
      totalFat:      FieldValue.increment(macros.fat),
      updatedAt:     FieldValue.serverTimestamp(),
    });

    await batch.commit();

    return NextResponse.json({ success: true, macros });
  } catch (err) {
    console.error("[log-food]", err.message);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}