// src/app/api/food-search/route.js
// ─────────────────────────────────────────────────────────────────────────────
// Proxies text queries to the Open Food Facts v1 Search API.
// Running server-side avoids CORS blocks and lets us trim the payload
// before sending it to the client (raw OFF responses can be very large).
// ─────────────────────────────────────────────────────────────────────────────
import { NextResponse } from "next/server";

const OFF_BASE = "https://world.openfoodfacts.org/cgi/search.pl";

// Only fetch the fields we actually render in the UI
const FIELDS = [
  "code",
  "product_name",
  "brands",
  "serving_size",
  "image_thumb_url",
  "nutriments",
].join(",");

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get("q")?.trim();

  if (!query || query.length < 2) {
    return NextResponse.json({ products: [] });
  }

  try {
    const url = new URL(OFF_BASE);
    url.searchParams.set("search_terms",  query);
    url.searchParams.set("search_simple", "1");
    url.searchParams.set("action",        "process");
    url.searchParams.set("json",          "1");
    url.searchParams.set("page_size",     "20");
    url.searchParams.set("fields",        FIELDS);

    const res = await fetch(url.toString(), {
      headers: {
        // OFF asks API users to identify their app
        "User-Agent": "FuelTrack/1.0 (contact@fueltrack.app)",
      },
      // Next.js cache — reuse the same response for 1 hour
      next: { revalidate: 3600 },
    });

    if (!res.ok) throw new Error(`OFF returned ${res.status}`);
    const data = await res.json();

    // Normalize each product into a flat, typed shape
    const products = (data.products ?? [])
      .filter((p) => p.product_name && p.nutriments)
      .map((p) => ({
        id:          p.code,
        name:        p.product_name,
        brand:       p.brands?.split(",")[0]?.trim() ?? "",
        servingSize: p.serving_size ?? "100g",
        imageUrl:    p.image_thumb_url ?? null,
        nutrition: {
          // OFF stores per-100g values in nutriments
          calories: Math.round(p.nutriments["energy-kcal_100g"] ?? 0),
          protein:  Math.round(p.nutriments["proteins_100g"]     ?? 0),
          carbs:    Math.round(p.nutriments["carbohydrates_100g"] ?? 0),
          fat:      Math.round(p.nutriments["fat_100g"]           ?? 0),
        },
      }));

    return NextResponse.json({ products });
  } catch (err) {
    console.error("[food-search]", err.message);
    return NextResponse.json({ error: "Search failed" }, { status: 500 });
  }
}